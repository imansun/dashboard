export { Table } from "./Table";
export { TBody, TFoot, THead, Th, Tr, Td } from "./TableTags"; 