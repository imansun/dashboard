
const config = {
    "tailwindFunctions": ["clsx", "cn"],
    "tailwindAttributes": ["rootClass", "classNames"],
    "plugins": [
        "prettier-plugin-tailwindcss"
    ],

}

export default config