
// Import Dependencies
import { CalendarIcon, XMarkIcon } from "@heroicons/react/24/outline";
import moment from "jalali-moment";
// Local Imports
import { Button } from "@/components/ui";
import { useLocaleContext } from "@/app/contexts/locale/context";

// ----------------------------------------------------------------------

export function Header({ close }: { close: () => void }) {
  const { locale } = useLocaleContext();
  const now = moment().locale(locale).format("DD MMMM, YYYY");

  return (
    <div className="flex items-center justify-between px-4 py-2">
      <div className="flex shrink-0 items-center gap-1.5">
        <CalendarIcon className="size-4" />
        <span>{now}</span>
      </div>
      <Button
        onClick={close}
        variant="flat"
        isIcon
        className="size-6 rounded-full ltr:-mr-1 rtl:-ml-1"
      >
        <XMarkIcon className="size-4" />
      </Button>
    </div>
  );
}
