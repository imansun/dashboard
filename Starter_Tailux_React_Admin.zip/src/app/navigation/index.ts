import { dashboards } from "./segments/dashboards";

export const navigation = [
  dashboards,
];
